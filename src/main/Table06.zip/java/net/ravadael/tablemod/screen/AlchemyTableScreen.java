
package net.ravadael.tablemod.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.tooltip.DefaultTooltipPositioner;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.ravadael.tablemod.TableMod;
import net.ravadael.tablemod.menu.AlchemyTableMenu;

import java.util.List;

public class AlchemyTableScreen extends AbstractContainerScreen<AlchemyTableMenu> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(TableMod.MOD_ID, "textures/gui/alchemy_table.png");

    private static final int BUTTON_WIDTH = 16;
    private static final int BUTTON_HEIGHT = 16;
    private static final int BUTTONS_PER_COLUMN = 4;
    private static final int BUTTONS_PER_ROW = 3;
    private static final int BUTTON_START_X = 60;
    private static final int BUTTON_START_Y = 17;

    public AlchemyTableScreen(AlchemyTableMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShaderTexture(0, TEXTURE);
        guiGraphics.blit(TEXTURE, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight);

        // Scrollbar background
        if (menu.canScroll()) {
            int barX = leftPos + 119;
            int barY = topPos + 15;
            guiGraphics.blit(TEXTURE, barX, barY, 176, 0, 12, 56); // scroll background
            int thumbY = (int) ((menu.getVisibleRecipes().size() / (float) menu.DISPLAY_COUNT) * 44);
            guiGraphics.blit(TEXTURE, barX, barY + thumbY, 188, 0, 12, 15); // scroll thumb
        }

        // Render buttons
        List<ItemStack> results = menu.getVisibleRecipes();
        for (int i = 0; i < results.size(); i++) {
            int x = leftPos + BUTTON_START_X + (i % BUTTONS_PER_ROW) * (BUTTON_WIDTH + 4);
            int y = topPos + BUTTON_START_Y + (i / BUTTONS_PER_ROW) * (BUTTON_HEIGHT + 4);
            guiGraphics.renderItem(results.get(i), x, y);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (menu.hasRecipes()) {
            List<ItemStack> recipes = menu.getVisibleRecipes();
            for (int i = 0; i < recipes.size(); i++) {
                int x = leftPos + BUTTON_START_X + (i % BUTTONS_PER_ROW) * (BUTTON_WIDTH + 4);
                int y = topPos + BUTTON_START_Y + (i / BUTTONS_PER_ROW) * (BUTTON_HEIGHT + 4);
                if (mouseX >= x && mouseX < x + BUTTON_WIDTH && mouseY >= y && mouseY < y + BUTTON_HEIGHT) {
                    // Simulate selection: place result in output slot
                    menu.getBlockEntity().setItem(2, recipes.get(i).copy());
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(guiGraphics);
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        this.renderTooltip(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        guiGraphics.drawString(this.font, this.title, 8, 6, 4210752, false);
        guiGraphics.drawString(this.font, this.playerInventoryTitle, 8, this.imageHeight - 96 + 2, 4210752, false);
    }
}
