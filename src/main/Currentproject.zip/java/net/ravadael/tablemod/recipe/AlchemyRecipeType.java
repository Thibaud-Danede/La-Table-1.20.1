package net.ravadael.tablemod.recipe;

import net.minecraft.world.item.crafting.RecipeType;

public class AlchemyRecipeType implements RecipeType<AlchemyRecipe> {
    public static RecipeType<AlchemyRecipe> INSTANCE;

    private AlchemyRecipeType() {}
}
