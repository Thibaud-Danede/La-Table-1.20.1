package net.ravadael.tablemod.menu.slot;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.ravadael.tablemod.block.entity.AlchemyTableBlockEntity;
import net.ravadael.tablemod.menu.AlchemyTableMenu;

public class ResultSlot extends Slot {
    private final AlchemyTableBlockEntity blockEntity;

    public ResultSlot(Container container, AlchemyTableBlockEntity blockEntity, int index, int x, int y) {
        super(container, index, x, y);
        this.blockEntity = blockEntity;
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return false; // slot d’output
    }

    @Override
    public void onTake(Player player, ItemStack stack) {
        if (!player.level().isClientSide && player.containerMenu instanceof AlchemyTableMenu m) {

            if (!m.canCraftOnce()) {
                m.refreshOutput();
                return;
            }

            blockEntity.removeItem(0, 1);
            blockEntity.removeItem(1, 1);
            blockEntity.setChanged();

            m.refreshRecipeList();  // ← revalidate available outputs
            m.refreshOutput();
            m.broadcastChanges();   // ← ensures client stays in sync
        }

        super.onTake(player, stack);
    }


    @Override
    public boolean mayPickup(net.minecraft.world.entity.player.Player player) {
        // le client peut “cliquer”, mais on ne valide que si le serveur dit OK
        if (player.level().isClientSide) return true;

        if (player.containerMenu instanceof net.ravadael.tablemod.menu.AlchemyTableMenu m) {
            return m.canCraftOnce(); // ← interdit le ghost pickup
        }
        return false;
    }
}

