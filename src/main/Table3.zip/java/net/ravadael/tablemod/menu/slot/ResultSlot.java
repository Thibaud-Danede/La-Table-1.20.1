package net.ravadael.tablemod.menu.slot;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.ravadael.tablemod.block.entity.AlchemyTableBlockEntity;

public class ResultSlot extends Slot {
    private final AlchemyTableBlockEntity blockEntity;

    public ResultSlot(Container container, AlchemyTableBlockEntity blockEntity, int index, int x, int y) {
        super(container, index, x, y);
        this.blockEntity = blockEntity;
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return false; // slot d’output
    }

    @Override
    public void onTake(net.minecraft.world.entity.player.Player player, net.minecraft.world.item.ItemStack stack) {
        if (!player.level().isClientSide && player.containerMenu instanceof net.ravadael.tablemod.menu.AlchemyTableMenu m) {

            // 1) Revalide juste avant de consommer (évite une course)
            if (!m.canCraftOnce()) {
                // plus craftable -> on vide l’output et on sort
                m.refreshOutput();
                return;
            }

            // 2) Consommer les matières (ADAPTE si coûts ≠ 1)
            this.blockEntity.removeItem(0, 1);
            this.blockEntity.removeItem(1, 1);
            this.blockEntity.setChanged();

            // 3) Refaire SEULEMENT un refresh léger de l’output
            //    (si un slot est devenu vide, refreshOutput() mettra l’output à vide)
            m.refreshOutput();
        }

        super.onTake(player, stack);
    }

    @Override
    public boolean mayPickup(net.minecraft.world.entity.player.Player player) {
        // le client peut “cliquer”, mais on ne valide que si le serveur dit OK
        if (player.level().isClientSide) return true;

        if (player.containerMenu instanceof net.ravadael.tablemod.menu.AlchemyTableMenu m) {
            return m.canCraftOnce(); // ← interdit le ghost pickup
        }
        return false;
    }
}

