
package net.ravadael.tablemod.menu;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;
import net.ravadael.tablemod.block.entity.AlchemyTableBlockEntity;
import net.ravadael.tablemod.menu.slot.ResultSlot;

import java.util.ArrayList;
import java.util.List;

public class AlchemyTableMenu extends AbstractContainerMenu {
    private final AlchemyTableBlockEntity blockEntity;
    private final ContainerLevelAccess access;
    private final Level level;
    private final Player player;
    private final List<ItemStack> recipeResults = new ArrayList<>();
    private int selectedIndex = -1;

    private int startIndex = 0;

    public static final int DISPLAY_COUNT = 12;

    private final net.minecraft.world.inventory.ResultContainer result = new net.minecraft.world.inventory.ResultContainer();


    public AlchemyTableMenu(int id, Inventory inv, FriendlyByteBuf extraData) {
        this(id, inv, (AlchemyTableBlockEntity) inv.player.level().getBlockEntity(extraData.readBlockPos()));

    }

    public AlchemyTableMenu(int id, Inventory inv, AlchemyTableBlockEntity blockEntity) {
        super(ModMenuTypes.ALCHEMY_TABLE_MENU.get(), id);
        this.blockEntity = blockEntity;
        this.access = ContainerLevelAccess.create(blockEntity.getLevel(), blockEntity.getBlockPos());
        this.level = inv.player.level();

        // Input (Plank)
        this.addSlot(new Slot(blockEntity, 0, 20, 23));
        // Fuel (Glowstone)
        this.addSlot(new Slot(blockEntity, 1, 20, 42));
        // Output sur ResultContainer au lieu du BE
        this.addSlot(new ResultSlot(this.result, this.blockEntity, 0, 143, 32));


        // Player inventory
        for (int row = 0; row < 3; ++row)
            for (int col = 0; col < 9; ++col)
                this.addSlot(new Slot(inv, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));

        for (int k = 0; k < 9; ++k)
            this.addSlot(new Slot(inv, k, 8 + k * 18, 142));

        refreshRecipeList();
        this.player = inv.player;

    }

    public void refreshRecipeList() {
        recipeResults.clear();
        ItemStack input = blockEntity.getItem(0);
        ItemStack fuel = blockEntity.getItem(1);

        if (!input.isEmpty() && input.is(Items.OAK_PLANKS) && !fuel.isEmpty() && fuel.is(Items.GLOWSTONE_DUST)) {
            recipeResults.add(new ItemStack(Items.OAK_SLAB));
            recipeResults.add(new ItemStack(Items.OAK_STAIRS));
            recipeResults.add(new ItemStack(Items.OAK_FENCE));
            recipeResults.add(new ItemStack(Items.OAK_TRAPDOOR));
        }

        // Reset selected recipe if input/fuel changed
        if (selectedIndex >= recipeResults.size()) {
            selectedIndex = -1;
            result.setItem(0, ItemStack.EMPTY);
        }
    }


    public List<ItemStack> getVisibleRecipes() {
        int end = Math.min(startIndex + DISPLAY_COUNT, recipeResults.size());
        return recipeResults.subList(startIndex, end);
    }

    public boolean hasRecipes() {
        return !recipeResults.isEmpty();
    }

    public boolean canScroll() {
        return recipeResults.size() > DISPLAY_COUNT;
    }

    public void scrollUp() {
        if (startIndex > 0) {
            startIndex--;
        }
    }

    public void scrollDown() {
        if (startIndex + DISPLAY_COUNT < recipeResults.size()) {
            startIndex++;
        }
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return this.blockEntity != null && this.blockEntity.getLevel().getBlockEntity(this.blockEntity.getBlockPos()) == this.blockEntity &&
                player.distanceToSqr(this.blockEntity.getBlockPos().getCenter()) < 64.0;
    }

    public AlchemyTableBlockEntity getBlockEntity() {
        return blockEntity;
    }

    public int getStartIndex() {
        return startIndex;
    }

    public int getTotalRecipeCount() {
        return recipeResults.size();
    }

    public Player getPlayer() {
        return this.player;
    }

    public void setSelectedIndex(int index) {
        if (index >= 0 && index < recipeResults.size()) {
            this.selectedIndex = index;
            result.setItem(0, recipeResults.get(index).copy());
        } else {
            this.selectedIndex = -1;
            result.setItem(0, ItemStack.EMPTY);
        }
    }

    public void selectRecipe(int index) {
        if (this.level.isClientSide) return; // ← important : logique serveur uniquement

        if (index >= 0 && index < recipeResults.size()) {
            this.selectedIndex = index;
            ItemStack out = recipeResults.get(index).copy();
            result.setItem(0, out);            // ← on pose l’output côté serveur
        } else {
            this.selectedIndex = -1;
            result.setItem(0, ItemStack.EMPTY);
        }
        this.broadcastChanges(); // sync slots aux clients
    }

    @Override
    public boolean clickMenuButton(net.minecraft.world.entity.player.Player player, int id) {
        if (this.level.isClientSide) return true;
        this.selectedIndex = id;
        this.refreshOutput(); // léger
        return true;
    }

    @Override
    public void slotsChanged(net.minecraft.world.Container c) {
        super.slotsChanged(c);
        if (this.level.isClientSide) return;

        if (c == this.blockEntity) { // tes slots 0/1 vivent dans le BE
            this.rebuildAvailable(); // lourd -> uniquement quand input/fuel changent
        }
    }

    private void updateAvailableRecipes() {
        ItemStack in = blockEntity.getItem(0);
        ItemStack fuel = blockEntity.getItem(1);

        // Remplis recipeResults en fonction des règles de ton mod
        // (si tu as déjà un code qui remplit 'recipeResults', appelle-le ici)
        // Exemples :
        // this.recipeResults = MyRecipeFinder.find(level, in, fuel);
        // ou reconstruire la liste comme tu le fais déjà au moment où tu affiches

        // Si l’input ou le fuel sont vides, vide la sélection/slot 2
        if (in.isEmpty() || fuel.isEmpty()) {
            this.selectedIndex = -1;
            result.setItem(0, ItemStack.EMPTY);
        }
    }

    public void rebuildAvailable() {
        if (this.level.isClientSide) return;

        if (this.selectedIndex < 0 || this.selectedIndex >= this.recipeResults.size()) {
            this.selectedIndex = -1;
        }
        this.refreshOutput();
    }

    // Donne la recette sélectionnée, ou null si index invalide
    public @org.jetbrains.annotations.Nullable net.minecraft.world.item.ItemStack getSelectedOutputCopy() {
        if (this.selectedIndex >= 0 && this.selectedIndex < this.recipeResults.size()) {
            return this.recipeResults.get(this.selectedIndex).copy();
        }
        return net.minecraft.world.item.ItemStack.EMPTY;
    }

    // TRUE si l’artisanat peut être réalisé AU MOINS une fois avec l’état actuel des slots 0/1
    public boolean canCraftOnce() {
        if (this.selectedIndex < 0 || this.selectedIndex >= this.recipeResults.size()) return false;

        // Lis l’état courant des inputs dans le BE
        net.minecraft.world.item.ItemStack in   = this.blockEntity.getItem(0);
        net.minecraft.world.item.ItemStack fuel = this.blockEntity.getItem(1);
        if (in.isEmpty() || fuel.isEmpty()) return false;

        // === ADAPTE ICI si tu as des coûts variables ===
        // Si pour l’instant c’est 1 input + 1 fuel par craft :
        int inCost = 1;
        int fuelCost = 1;
        return in.getCount() >= inCost && fuel.getCount() >= fuelCost;
    }

    public void refreshOutput() {
        // au début de refreshOutput()
        if (this.blockEntity.getItem(0).isEmpty() || this.blockEntity.getItem(1).isEmpty()) {
            this.result.setItem(0, net.minecraft.world.item.ItemStack.EMPTY);
            this.broadcastChanges();
            return;
        }

        if (this.level.isClientSide) return;

        net.minecraft.world.item.ItemStack out = net.minecraft.world.item.ItemStack.EMPTY;
        if (this.canCraftOnce()) {
            out = getSelectedOutputCopy();
        }
        this.result.setItem(0, out);
        this.broadcastChanges();
    }


}
