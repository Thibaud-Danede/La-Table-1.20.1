package net.ravadael.tablemod.menu.slot;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.ravadael.tablemod.block.entity.AlchemyTableBlockEntity;

public class ResultSlot extends Slot {
    private final AlchemyTableBlockEntity blockEntity;

    public ResultSlot(Container container, AlchemyTableBlockEntity blockEntity, int index, int x, int y) {
        super(container, index, x, y);
        this.blockEntity = blockEntity;
    }


    @Override
    public boolean mayPlace(ItemStack stack) {
        return false;
    }

    @Override
    public void onTake(Player player, ItemStack stack) {
        // Consume 1 input
        ItemStack input = blockEntity.getItem(0);
        if (!input.isEmpty()) {
            input.shrink(1);
            blockEntity.setItem(0, input);
        }

        // Consume 1 fuel
        ItemStack fuel = blockEntity.getItem(1);
        if (!fuel.isEmpty()) {
            fuel.shrink(1);
            blockEntity.setItem(1, fuel);
        }

        // Clear result slot
        blockEntity.setItem(2, ItemStack.EMPTY);

        blockEntity.setChanged();

        super.onTake(player, stack); // ← do this *after* updates
        System.out.println("Crafted: " + stack);
    }



    @Override
    public boolean mayPickup(Player player) {
        System.out.println("May pickup: " + getItem());
        return !this.getItem().isEmpty();
    }
}
