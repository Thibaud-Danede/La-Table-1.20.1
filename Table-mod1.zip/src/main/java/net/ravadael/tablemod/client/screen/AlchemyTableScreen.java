
package net.ravadael.tablemod.client.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.ravadael.tablemod.TableMod;
import net.ravadael.tablemod.menu.AlchemyTableMenu;
import net.ravadael.tablemod.recipe.AlchemyRecipe;

import java.util.List;

public class AlchemyTableScreen extends AbstractContainerScreen<AlchemyTableMenu> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(TableMod.MOD_ID, "textures/gui/alchemy_table.png");

    private List<AlchemyRecipe> recipeList;
    private float scrollAmount = 0.0F;

    public AlchemyTableScreen(AlchemyTableMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
    }

    @Override
    protected void init() {
        super.init();
        this.titleLabelX = 8;
        this.recipeList = menu.getAvailableRecipes();
        this.scrollAmount = 0.0F;
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        guiGraphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);

        recipeList = menu.getAvailableRecipes();
        if (recipeList == null || recipeList.isEmpty()) return;

        int offset = (int) scrollAmount * 5;
        var registryAccess = Minecraft.getInstance().level.registryAccess();

        for (int i = 0; i < 15 && i + offset < recipeList.size(); i++) {
            AlchemyRecipe recipe = recipeList.get(i + offset);
            int row = i / 5;
            int col = i % 5;
            int x = leftPos + 12 + col * 18;
            int y = topPos + 18 + row * 18;

            ItemStack result = recipe.getResultItem(registryAccess);
            if (!result.isEmpty()) {
                guiGraphics.renderItem(result, x, y);
                guiGraphics.renderItemDecorations(this.font, result, x, y);
            }
        }

        if (recipeList.size() > 15) {
            int scrollbarHeight = 54;
            int handleHeight = 15;
            int maxScroll = Math.max(1, (recipeList.size() + 4) / 5 - 3);
            int scrollY = topPos + 18 + (int)((scrollAmount / maxScroll) * (scrollbarHeight - handleHeight));

            guiGraphics.blit(TEXTURE, leftPos + 119, scrollY, 176, 0, 6, handleHeight);
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        int rows = (recipeList.size() + 4) / 5;
        int visibleRows = 3;
        int maxScroll = Math.max(0, rows - visibleRows);

        scrollAmount = (float)Math.max(0, Math.min(scrollAmount - delta * 0.25F, maxScroll));
        return true;
    }
}
